import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, AlertController, ToastController } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UsuarioService } from '../../services/usuario.service';
import { Usuario } from '../../model/usuario.model';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule, FormsModule]
})
export class PerfilPage implements OnInit {
  usuario: Usuario | null = null;
  usuarioId: number = 0;
  isLoading = false;
  isEditing = false;
  isChangingPassword = false;

  // Dados do perfil
  nome: string = '';
  bio: string = '';
  email: string = '';
  dataNascimento: string = '';
  imagem: string = '';

  // Dados de senha
  senhaAtual: string = '';
  novaSenha: string = '';
  confirmarSenha: string = '';

  // Configurações
  notificacoes: boolean = true;
  som: boolean = true;

  constructor(
    private usuarioService: UsuarioService,
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    this.carregarUsuario();
  }

  carregarUsuario() {
    // Recupera o ID do usuário do sessionStorage
    const userData = sessionStorage.getItem('user');
    if (userData) {
      try {
        const user = JSON.parse(userData);
        this.usuarioId = user.id || 0;
        this.usuario = user;
        this.nome = user.nome || '';
        this.bio = user.bio || '';
        this.email = user.email || '';
        this.dataNascimento = user.dataNascimento ? new Date(user.dataNascimento).toISOString().split('T')[0] : '';
        this.imagem = user.imagem || '';
        this.notificacoes = user.notificacoes !== undefined ? user.notificacoes : true;
        this.som = user.som !== undefined ? user.som : true;
      } catch (error) {
        console.error('Erro ao carregar usuário:', error);
        this.router.navigate(['/login']);
      }
    } else {
      this.router.navigate(['/login']);
    }
  }

  // ==================== ATUALIZAR PERFIL ====================
  async atualizarPerfil() {
    if (!this.usuarioId) {
      this.mostrarToast('Usuário não identificado', 'danger');
      return;
    }

    this.isLoading = true;
    try {
      // Cria um novo usuário com os dados atualizados
      const usuarioAtualizado = new Usuario(
        this.usuarioId,
        this.nome,
        this.email,
        this.usuario?.senha || '', // Mantém a senha atual
        this.imagem,
        this.bio,
        this.dataNascimento,
        this.usuario?.tema || 1,
        this.usuario?.idioma || 1,
        this.notificacoes,
        this.som,
        this.usuario?.sequenciaDias || 0,
        this.usuario?.pontuacaoTotal || 0,
        this.usuario?.nivelUsuario || 1,
        this.usuario?.xpTotal || 0,
        this.usuario?.ativo !== undefined ? this.usuario.ativo : true,
        this.usuario?.dataCadastro,
        this.usuario?.ultimoLogin
      );

      const resultado = await this.usuarioService.atualizar(this.usuarioId, usuarioAtualizado).toPromise();

      // Atualiza o usuário no sessionStorage
      if (resultado) {
        sessionStorage.setItem('user', JSON.stringify(resultado));
        this.usuario = resultado;
        this.mostrarToast('Perfil atualizado com sucesso! ✅', 'success');
        this.isEditing = false;
      }
    } catch (error: any) {
      console.error('Erro ao atualizar perfil:', error);
      const mensagem = error.error?.message || 'Erro ao atualizar perfil';
      this.mostrarToast(mensagem, 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  // ==================== ALTERAR SENHA ====================
  async alterarSenha() {
    if (!this.senhaAtual || !this.novaSenha || !this.confirmarSenha) {
      this.mostrarToast('Preencha todos os campos de senha', 'warning');
      return;
    }

    if (this.novaSenha.length < 6) {
      this.mostrarToast('A nova senha deve ter pelo menos 6 caracteres', 'warning');
      return;
    }

    if (this.novaSenha !== this.confirmarSenha) {
      this.mostrarToast('As senhas não coincidem', 'danger');
      return;
    }

    if (!this.usuarioId) {
      this.mostrarToast('Usuário não identificado', 'danger');
      return;
    }

    this.isLoading = true;
    try {
      // Busca o usuário atual
      const usuarioAtual = await this.usuarioService.buscarPorId(this.usuarioId).toPromise();
      
      if (usuarioAtual) {
        // Atualiza a senha
        usuarioAtual.senha = this.novaSenha;
        
        await this.usuarioService.atualizar(this.usuarioId, usuarioAtual).toPromise();
        
        this.mostrarToast('Senha alterada com sucesso! 🔒', 'success');
        
        // Limpa os campos
        this.senhaAtual = '';
        this.novaSenha = '';
        this.confirmarSenha = '';
        this.isChangingPassword = false;
      }
    } catch (error: any) {
      console.error('Erro ao alterar senha:', error);
      const mensagem = error.error?.message || 'Erro ao alterar senha';
      this.mostrarToast(mensagem, 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  // ==================== UPLOAD DE IMAGEM ====================
  async uploadImagem() {
    const alert = await this.alertController.create({
      header: 'URL da imagem',
      inputs: [
        {
          name: 'url',
          type: 'text',
          placeholder: 'https://exemplo.com/imagem.jpg',
          label: 'URL da imagem'
        }
      ],
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Salvar',
          handler: (data) => {
            if (data.url) {
              this.imagem = data.url;
              this.mostrarToast('Imagem atualizada!', 'success');
            }
          }
        }
      ]
    });

    await alert.present();
  }

  // ==================== HELPERS ====================
  toggleEdit() {
    this.isEditing = !this.isEditing;
    if (!this.isEditing) {
      // Recarrega os dados originais se cancelar
      this.carregarUsuario();
    }
  }

  togglePasswordChange() {
    this.isChangingPassword = !this.isChangingPassword;
    if (!this.isChangingPassword) {
      this.senhaAtual = '';
      this.novaSenha = '';
      this.confirmarSenha = '';
    }
  }

  voltar() {
    this.router.navigate(['/home']);
  }

  private mostrarToast(message: string, color: string = 'primary') {
    this.toastController.create({
      message,
      duration: 3000,
      color,
      position: 'bottom',
      mode: 'ios'
    }).then(toast => toast.present());
  }
}
