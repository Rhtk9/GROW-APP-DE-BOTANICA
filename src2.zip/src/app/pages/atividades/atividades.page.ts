import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, AlertController, ToastController, SegmentCustomEvent } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AtividadeService } from '../../services/atividade.service';
import { TurmaService } from '../../services/turma.service';
import { AuthService } from '../../core/services/auth.service';
import { Atividade } from '../../model/atividade.model';
import { Turma } from '../../model/turma.model';

@Component({
  selector: 'app-atividades',
  templateUrl: './atividades.page.html',
  styleUrls: ['./atividades.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule, FormsModule]
})
export class AtividadesPage implements OnInit {
  atividades: Atividade[] = [];
  turmaId?: number;
  turma: Turma | null = null;
  isLoading = false;
  filtro: 'todas' | 'futuras' | 'passadas' = 'todas';
  usuarioId!: number;
  isProfessor = true; // 🔥 MUDANÇA: começa como true para mostrar o botão

  constructor(
    private atividadeService: AtividadeService,
    private turmaService: TurmaService,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    console.log('🔥 Página ATIVIDADES carregada!');
    
    const user = this.authService.currentUser;
    if (user) {
      this.usuarioId = user.id || 0;
    }

    this.route.params.subscribe(params => {
      this.turmaId = params['turmaId'] ? +params['turmaId'] : undefined;
      this.carregarDados();
    });
  }

  async carregarDados() {
    if (!this.turmaId) {
      await this.carregarAtividadesDoUsuario();
      return;
    }

    this.isLoading = true;
    try {
      this.turma = await this.turmaService.buscarPorId(this.turmaId).toPromise() || null;
      // 🔥 MUDANÇA: SEMPRE define como true quando tem turmaId
      this.isProfessor = true;
      await this.carregarAtividadesDaTurma();
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      this.mostrarToast('Erro ao carregar atividades', 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  async carregarAtividadesDaTurma() {
    if (!this.turmaId) return;

    try {
      if (this.filtro === 'futuras') {
        this.atividades = await this.atividadeService.listarFuturasPorTurma(this.turmaId).toPromise() || [];
      } else if (this.filtro === 'passadas') {
        this.atividades = await this.atividadeService.listarPassadasPorTurma(this.turmaId).toPromise() || [];
      } else {
        this.atividades = await this.atividadeService.listarPorTurma(this.turmaId).toPromise() || [];
      }
      
      this.atividades.sort((a, b) => 
        new Date(a.dataEntrega).getTime() - new Date(b.dataEntrega).getTime()
      );
    } catch (error) {
      console.error('Erro ao carregar atividades:', error);
      throw error;
    }
  }

  async carregarAtividadesDoUsuario() {
    this.isLoading = true;
    try {
      this.atividades = await this.atividadeService.listarPorUsuario(this.usuarioId).toPromise() || [];
      // 🔥 MUDANÇA: quando não tem turmaId, NÃO mostra botão de criar
      this.isProfessor = false;
    } catch (error) {
      console.error('Erro ao carregar atividades:', error);
      this.mostrarToast('Erro ao carregar atividades', 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  async aplicarFiltro(event: SegmentCustomEvent) {
    const value = event.detail.value;
    if (value === 'todas' || value === 'futuras' || value === 'passadas') {
      this.filtro = value;
    } else {
      this.filtro = 'todas';
    }
    
    if (this.turmaId) {
      await this.carregarAtividadesDaTurma();
    }
  }

  async abrirCriarAtividade() {
    if (!this.turmaId) {
      this.mostrarToast('Selecione uma turma primeiro', 'warning');
      return;
    }

    const alert = await this.alertController.create({
      header: 'Criar nova atividade',
      subHeader: `Turma: ${this.turma?.nome}`,
      inputs: [
        {
          name: 'titulo',
          type: 'text',
          placeholder: 'Ex: Fotosíntese - Parte 1',
          label: 'Título da atividade'
        },
        {
          name: 'descricao',
          type: 'textarea',
          placeholder: 'Descreva a atividade...',
          label: 'Descrição'
        },
        {
          name: 'pontuacao',
          type: 'number',
          placeholder: '100',
          label: 'Pontuação',
          value: '100'
        },
        {
          name: 'xp',
          type: 'number',
          placeholder: '50',
          label: 'XP',
          value: '50'
        },
        {
          name: 'dataEntrega',
          type: 'date',
          label: 'Data de entrega'
        },
        {
          name: 'tentativas',
          type: 'number',
          placeholder: '3',
          label: 'Tentativas permitidas',
          value: '3'
        },
        {
          name: 'dificuldade',
          type: 'number',
          placeholder: '1 a 5',
          label: 'Dificuldade (1-5)',
          value: '1'
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Criar',
          handler: async (data) => {
            if (!data.titulo || !data.descricao || !data.dataEntrega) {
              this.mostrarToast('Preencha todos os campos obrigatórios', 'warning');
              return false;
            }
            await this.criarAtividade(data);
            return true;
          }
        }
      ]
    });

    await alert.present();
  }

  async criarAtividade(data: any) {
    this.isLoading = true;
    try {
      const novaAtividade = new Atividade();
      novaAtividade.titulo = data.titulo;
      novaAtividade.descricao = data.descricao;
      novaAtividade.pontuacao = parseInt(data.pontuacao) || 100;
      novaAtividade.xp = parseInt(data.xp) || 50;
      novaAtividade.dataEntrega = data.dataEntrega;
      novaAtividade.tentativas = parseInt(data.tentativas) || 3;
      novaAtividade.status = 'ABERTA';
      novaAtividade.dificuldade = parseInt(data.dificuldade) || 1;
      novaAtividade.turmaId = this.turmaId!;

      await this.atividadeService.criar(novaAtividade).toPromise();
      
      this.mostrarToast('Atividade criada com sucesso! 📝', 'success');
      await this.carregarDados();
    } catch (error: any) {
      console.error('Erro ao criar atividade:', error);
      const mensagem = error.error?.message || 'Erro ao criar atividade';
      this.mostrarToast(mensagem, 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  async verDetalhes(atividade: Atividade) {
    const alert = await this.alertController.create({
      header: atividade.titulo,
      subHeader: `Turma: ${atividade.turmaNome || 'N/A'}`,
      message: `
        <div style="text-align: left; padding: 8px 0;">
          <p><strong>📝 Descrição:</strong> ${atividade.descricao}</p>
          <p><strong>⭐ Pontuação:</strong> ${atividade.pontuacao}</p>
          <p><strong>✨ XP:</strong> ${atividade.xp}</p>
          <p><strong>📅 Entrega:</strong> ${new Date(atividade.dataEntrega).toLocaleDateString('pt-BR')}</p>
          <p><strong>🔄 Tentativas:</strong> ${atividade.tentativas}</p>
          <p><strong>📊 Status:</strong> ${atividade.status}</p>
          <p><strong>🎯 Dificuldade:</strong> ${'⭐'.repeat(atividade.dificuldade || 0)}</p>
          <p><strong>👨‍🎓 Alunos:</strong> ${atividade.totalAlunos || 0}</p>
          <p><strong>✅ Concluídos:</strong> ${atividade.alunosConcluidos || 0}</p>
        </div>
      `,
      buttons: [
        { text: 'Fechar', role: 'cancel' }
      ]
    });

    await alert.present();
  }

  getStatusIcon(status: string): string {
    const map: Record<string, string> = {
      'ABERTA': 'time-outline',
      'EM_ANDAMENTO': 'play-circle-outline',
      'FECHADA': 'checkmark-circle-outline',
      'ENTREGUE': 'checkmark-done-circle-outline'
    };
    return map[status?.toUpperCase() || ''] || 'help-circle-outline';
  }

  getStatusColor(status: string): string {
    const map: Record<string, string> = {
      'ABERTA': 'success',
      'EM_ANDAMENTO': 'warning',
      'FECHADA': 'danger',
      'ENTREGUE': 'tertiary'
    };
    return map[status?.toUpperCase() || ''] || 'medium';
  }

  getDiasRestantes(dataEntrega: string): number {
    const hoje = new Date();
    const entrega = new Date(dataEntrega);
    const diff = Math.ceil((entrega.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  }

  getStatusEntrega(dataEntrega: string): 'urgente' | 'pendente' | 'concluido' {
    const dias = this.getDiasRestantes(dataEntrega);
    if (dias < 0) return 'concluido';
    if (dias <= 3) return 'urgente';
    return 'pendente';
  }

  voltar() {
    this.router.navigate(['/turmas']);
  }

  private mostrarToast(message: string, color: string = 'primary') {
    this.toastController.create({
      message,
      duration: 3000,
      color,
      position: 'bottom',
      mode: 'ios'
    }).then(toast => toast.present());
  }
}