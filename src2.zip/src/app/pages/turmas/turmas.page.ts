import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, AlertController, ToastController } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TurmaService } from '../../services/turma.service';
import { UsuarioTurmaService } from '../../services/usuario-turma.service';
import { AuthService } from '../../core/services/auth.service';
import { Turma } from '../../model/turma.model';
import { UsuarioTurma } from '../../model/usuario-turma.model';

@Component({
  selector: 'app-turmas',
  templateUrl: './turmas.page.html',
  styleUrls: ['./turmas.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule, FormsModule]
})
export class TurmasPage implements OnInit {
  turmas: Turma[] = [];
  turmasFiltradas: Turma[] = [];
  vinculos: UsuarioTurma[] = [];
  turmasVinculadas: Set<number> = new Set();
  favoritosVinculados: Set<number> = new Set();
  isLoading = false;
  termoBusca = '';
  usuarioId!: number;
  isProfessor = false;

  // Lista de atividades simuladas para cada turma
  private atividadesPorTurma: { [key: number]: string[] } = {
    1: ['Introdução à disciplina', 'Fotosíntese - Parte 1', 'Fotosíntese - Parte 2'],
    2: ['Botânica Básica', 'Sistemática Vegetal', 'Ecologia de Plantas'],
    3: ['Introdução à Ecologia', 'Ciclos Biogeoquímicos', 'Biodiversidade']
  };

  constructor(
    private turmaService: TurmaService,
    private usuarioTurmaService: UsuarioTurmaService,
    private authService: AuthService,
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    console.log('🔥 Página TURMAS carregada!');
    
    const user = this.authService.currentUser;
    if (user) {
      this.usuarioId = user.id || 0;
      this.carregarDados();
    } else {
      console.warn('⚠️ Usuário não autenticado');
    }
  }

  async carregarDados() {
    this.isLoading = true;
    try {
      // Carrega vínculos do usuário
      this.vinculos = await this.usuarioTurmaService.listarPorUsuario(this.usuarioId).toPromise() || [];
      
      this.turmasVinculadas = new Set(this.vinculos.map(v => v.turmaId));
      this.favoritosVinculados = new Set(
        this.vinculos.filter(v => v.favorito).map(v => v.turmaId)
      );

      // Carrega todas as turmas
      const todasTurmas = await this.turmaService.listarTodas().toPromise() || [];
      
      // Filtra apenas as turmas que o usuário está vinculado
      this.turmas = todasTurmas.filter(t => this.turmasVinculadas.has(t.id!));
      
      this.aplicarFiltro();
      this.isProfessor = this.turmas.length > 0;

    } catch (error) {
      console.error('Erro ao carregar turmas:', error);
      this.mostrarToast('Erro ao carregar turmas', 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  aplicarFiltro() {
    if (!this.termoBusca.trim()) {
      this.turmasFiltradas = [...this.turmas];
    } else {
      const termo = this.termoBusca.toLowerCase().trim();
      this.turmasFiltradas = this.turmas.filter(t =>
        t.nome?.toLowerCase().includes(termo) ||
        t.descricao?.toLowerCase().includes(termo) ||
        t.codigo?.toLowerCase().includes(termo)
      );
    }
  }

  onBuscar(event: any) {
    this.termoBusca = event.detail.value;
    this.aplicarFiltro();
  }

  // ==================== CRIAR TURMA ====================
  async abrirCriarTurma() {
    const alert = await this.alertController.create({
      header: 'Criar nova turma',
      subHeader: 'Você será o professor desta turma',
      inputs: [
        {
          name: 'nome',
          type: 'text',
          placeholder: 'Ex: Biologia 9º Ano A',
          label: 'Nome da turma'
        },
        {
          name: 'codigo',
          type: 'text',
          placeholder: 'Ex: BIO9A',
          label: 'Código da turma',
          value: this.gerarCodigoAleatorio()
        },
        {
          name: 'nivelEnsino',
          type: 'text',
          placeholder: 'Fundamental, Médio, Superior...',
          label: 'Nível de ensino'
        },
        {
          name: 'descricao',
          type: 'textarea',
          placeholder: 'Descreva a turma...',
          label: 'Descrição'
        }
      ],
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Criar',
          handler: async (data) => {
            if (!data.nome || !data.codigo || !data.nivelEnsino) {
              this.mostrarToast('Preencha todos os campos obrigatórios', 'warning');
              return false;
            }
            await this.criarTurma(data);
            return true;
          }
        }
      ]
    });

    await alert.present();
  }

  gerarCodigoAleatorio(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let codigo = '';
    for (let i = 0; i < 6; i++) {
      codigo += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return codigo;
  }

  async criarTurma(data: any) {
    this.isLoading = true;
    try {
      // Cria a turma
      const novaTurma = new Turma();
      novaTurma.nome = data.nome;
      novaTurma.codigo = data.codigo.toUpperCase();
      novaTurma.descricao = data.descricao || '';
      novaTurma.nivelEnsino = data.nivelEnsino;
      novaTurma.ano = new Date().getFullYear();

      const turmaCriada = await this.turmaService.criar(novaTurma).toPromise();
      
      if (turmaCriada && turmaCriada.id) {
        // Vincula o usuário à turma
        const vinculo = new UsuarioTurma();
        vinculo.usuarioId = this.usuarioId;
        vinculo.turmaId = turmaCriada.id;
        vinculo.ativo = true;
        vinculo.favorito = false;

        await this.usuarioTurmaService.criar(vinculo).toPromise();

        // Adiciona atividades simuladas para a nova turma
        this.atividadesPorTurma[turmaCriada.id] = [
          'Introdução à disciplina',
          'Atividade 1',
          'Atividade 2'
        ];

        this.mostrarToast('Turma criada com sucesso! 🎉', 'success');
        await this.carregarDados();
      }
    } catch (error: any) {
      console.error('Erro ao criar turma:', error);
      const mensagem = error.error?.message || 'Erro ao criar turma';
      this.mostrarToast(mensagem, 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  // ==================== ENTRAR EM TURMA ====================
  async abrirEntrarTurma() {
    const alert = await this.alertController.create({
      header: 'Entrar em turma',
      subHeader: 'Digite o código da turma',
      message: 'Peça o código ao seu professor',
      inputs: [
        {
          name: 'codigo',
          type: 'text',
          placeholder: 'Ex: BIO9A',
          attributes: { autofocus: true }
        }
      ],
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Entrar',
          handler: async (data) => {
            if (!data.codigo) {
              this.mostrarToast('Digite o código da turma', 'warning');
              return false;
            }
            await this.entrarTurma(data.codigo);
            return true;
          }
        }
      ]
    });

    await alert.present();
  }

  async entrarTurma(codigo: string) {
    this.isLoading = true;
    try {
      // Busca todas as turmas
      const turmas = await this.turmaService.listarTodas().toPromise() || [];
      const turma = turmas.find(t => 
        t.codigo?.toUpperCase() === codigo.trim().toUpperCase()
      );

      if (!turma || !turma.id) {
        this.mostrarToast('Turma não encontrada com este código', 'danger');
        this.isLoading = false;
        return;
      }

      // Verifica se já está vinculado
      if (this.turmasVinculadas.has(turma.id)) {
        this.mostrarToast('Você já está nesta turma', 'warning');
        this.isLoading = false;
        return;
      }

      // Vincula o usuário à turma
      const vinculo = new UsuarioTurma();
      vinculo.usuarioId = this.usuarioId;
      vinculo.turmaId = turma.id;
      vinculo.ativo = true;
      vinculo.favorito = false;

      await this.usuarioTurmaService.criar(vinculo).toPromise();

      // Adiciona atividades simuladas para a turma (se não tiver)
      if (!this.atividadesPorTurma[turma.id]) {
        this.atividadesPorTurma[turma.id] = [
          'Introdução à disciplina',
          'Atividade 1',
          'Atividade 2'
        ];
      }

      this.mostrarToast('Bem-vindo à turma! 🌱', 'success');
      await this.carregarDados();
    } catch (error: any) {
      console.error('Erro ao entrar na turma:', error);
      const mensagem = error.error?.message || 'Erro ao entrar na turma';
      this.mostrarToast(mensagem, 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  // ==================== FAVORITAR TURMA ====================
  async favoritarTurma(turma: Turma) {
    const vinculo = this.vinculos.find(v => v.turmaId === turma.id);
    if (!vinculo || !vinculo.id) return;

    this.isLoading = true;
    try {
      const novoFavorito = !this.favoritosVinculados.has(turma.id!);
      await this.usuarioTurmaService.favoritarDesfavoritar(vinculo.id, novoFavorito).toPromise();
      
      this.mostrarToast(
        novoFavorito ? 'Turma favoritada! ⭐' : 'Turma desfavoritada',
        novoFavorito ? 'success' : 'secondary'
      );
      await this.carregarDados();
    } catch (error) {
      console.error('Erro ao favoritar:', error);
      this.mostrarToast('Erro ao favoritar turma', 'danger');
    } finally {
      this.isLoading = false;
    }
  }

  // ==================== SAIR DA TURMA ====================
  async sairTurma(turma: Turma) {
    const alert = await this.alertController.create({
      header: 'Sair da Turma',
      message: `Tem certeza que deseja sair da turma "${turma.nome}"?`,
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Sair',
          role: 'destructive',
          handler: async () => {
            const vinculo = this.vinculos.find(v => v.turmaId === turma.id);
            if (!vinculo || !vinculo.id) return;

            this.isLoading = true;
            try {
              await this.usuarioTurmaService.excluir(vinculo.id).toPromise();
              this.mostrarToast('Você saiu da turma', 'secondary');
              await this.carregarDados();
            } catch (error) {
              console.error('Erro ao sair:', error);
              this.mostrarToast('Erro ao sair da turma', 'danger');
            } finally {
              this.isLoading = false;
            }
          }
        }
      ]
    });

    await alert.present();
  }

  // ==================== NAVEGAÇÃO ====================
  verAtividades(turma: Turma) {
    this.router.navigate(['/atividades', turma.id]);
  }

  // ==================== HELPERS ====================
  getProgresso(turma: Turma): number {
    return Math.min(100, (turma.quantidadeAtividades || 0) * 10);
  }

  /**
   * Retorna a próxima atividade da turma baseado no progresso
   */
  getNextActivity(turma: Turma): string | null {
    const progresso = this.getProgresso(turma);
    const atividades = this.atividadesPorTurma[turma.id!] || [];
    
    if (atividades.length === 0) {
      return null;
    }

    // Calcula qual atividade seria a "próxima" baseado no progresso
    const index = Math.min(
      Math.floor((progresso / 100) * atividades.length),
      atividades.length - 1
    );
    
    return atividades[index] || null;
  }

  getCorTurma(index: number): string {
    const cores = ['#2ECC71', '#3498DB', '#9B59B6', '#E67E22', '#1ABC9C'];
    return cores[index % cores.length];
  }

  private mostrarToast(message: string, color: string = 'primary') {
    this.toastController.create({
      message,
      duration: 3000,
      color,
      position: 'bottom',
      mode: 'ios'
    }).then(toast => toast.present());
  }
}